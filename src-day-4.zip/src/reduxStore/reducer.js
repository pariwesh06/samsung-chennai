export default function reducers(state, action) {
    console.log(state, action);
    switch (action.type) {
        case 'add':
            return {
                users: [
                    ...state.users, action.userform
                ]
            }
        default:
            return state;
    }
}