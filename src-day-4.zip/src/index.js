import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reducer from './reduxStore/reducer';
import { createStore } from 'redux';
import {Provider} from 'react-redux';
const initialState = [{ fname: 'ravi', age: 23 }];
const store = createStore(
    reducer,
    initialState//initial state
);
ReactDOM.render(<Provider store={store}>
    <App />
</Provider>, document.getElementById('root'));

