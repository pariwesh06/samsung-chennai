import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Searchform from './components/searchform/searchform';
import Orderform from './components/Orderform/Orderform';

class App extends Component {
 render(){
   return (
     <div>
       <Orderform></Orderform>
       <Counter></Counter>
     </div>
   )
 }
}

export default App;
