
import React , {Component} from 'react';

var Total = (props) => (<div >total: {props.totalSum}</div>)
export default Total;

// function foo(index){
//     return function inner(){
//         console.log(index);
//     }
// }
// var bar = foo(1);
// bar();
//nodeserver