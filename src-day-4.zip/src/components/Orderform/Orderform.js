import React, { Component } from 'react';
import { connect } from 'react-redux';
import * as formactions from '../../reduxStore/actions';
import { bindActionCreators } from 'redux';

const axios = require('axios');
const baseUrl = 'http://localhost:3000/posts';
class Orderform extends Component {
    constructor() {
        super();
        this.state = { users: [], 
        name:'ramesh' };
    }
    componentWillMount() {//callback
        console.log(arguments);
        axios.get(baseUrl)
            .then((response) => {
                // handle success
                this.setState({ users: response.data });
            })
    }
    render() {
        console.log('render');
        return (
            <div>
                <input value={this.state.name} onChange={event=> this.setState({name: event.target.value})}/>
                <button onClick={this.save=this.save.bind(this)}>save</button>
                <ol>
                    {this.state.users.map(user => <li>{user.name}</li>)}
                </ol>
            </div>
        )
    }
    save() {
        const headersObj = {};
        headersObj['Content-type'] = 'application/json';
        //  this.componentWillMount();// never call a callback
        fetch(baseUrl, {
            method: 'post',
            body: JSON.stringify({name:this.state.name}),
            headers: headersObj
        });
    }
}
function mapStateToProps(state, ownProps) {//state= redux state
    console.log('mapStateToProps', state);
    return {
        users: state.users
    };
}
function mapDispatchToProps(dispatch) {
    return {
        actions: bindActionCreators(formactions, dispatch)
    };
}
export default connect(mapStateToProps, mapDispatchToProps)(Orderform);