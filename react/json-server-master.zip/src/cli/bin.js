#!/usr/bin/env node
require('please-upgrade-node')(require('../../package.json'))
require('./')()
