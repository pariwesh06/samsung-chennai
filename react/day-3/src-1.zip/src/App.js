import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Searchform from './components/searchform/searchform';
class App extends Component {
 render(){
   return (
     <div>
       <Searchform></Searchform>
       
     </div>
   )
 }
}

export default App;
