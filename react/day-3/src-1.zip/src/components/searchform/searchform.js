import React, { Component } from 'react';
import Counter from '../counter/Counter';
class Searchform extends Component{
    constructor() {
        super();
        this.state = { fname: 'kishor', users: [] };
        this.sorted=true; 
        this.display = this.display.bind(this);
    
      }
      update(event) {
        // console.log(event.target.value);
        this.setState({ fname: event.target.value });
      }
    
      display() {
        // console.log(this.state.fname);
        // this.setState({ fname : 'ram'});
        this.state.users.push({ firstName: this.state.fname });
        this.setState({ users: this.state.users });
        var promise = fetch(`https://itunes.apple.com/search?term=${this.state.fname}&limit=`);
        promise.then((response) => {
          response.json().then((data) => {
            this.setState({ users: data.results });;
          })
        },
          function (error) {
            alert(error);
          })
        // this.setState({users :[ ...this.state.users,{firstName:this.state.fname}]});
      }
    
      render() {
        return (
          <div className="App">
            <input onChange={this.update = this.update.bind(this)} value={this.state.fname} />
            <input />
            <button onClick={this.display}>search</button>
            <button onClick={this.sort}>sort</button>
            <Counter count={ this.state.users.length}></Counter>
            <ol>
              {this.state.users.map(function (user) {
                return <li>{user.trackName}, {user.trackPrice}</li>
              })}
            </ol>
          </div>
        );
      }
}
export default Searchform;;