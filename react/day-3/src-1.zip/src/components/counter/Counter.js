import React, {Component} from 'react';

 class Counter extends Component{
     constructor(props){
         super(props);
     }
    render(){
        // this.props.count.push({});
        // console.log('"çhild"');
        return (
            <div>records:</div>
        )
    }
}
export default Counter;