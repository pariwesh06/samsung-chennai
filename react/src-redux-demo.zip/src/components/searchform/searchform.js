import React, { Component } from 'react';
import Counter from '../counter/Counter';
import Total from "../total/total";
class Searchform extends Component {
  constructor() {
    super();
    this.state = { fname: 'kishor', users: [] };
    this.sorted = true;
    this.display = this.display.bind(this);

  }
  update(event) {
    // console.log(event.target.value);
    this.setState({ fname: event.target.value });
  }

  display() {
    // console.log(this.state.fname);
    // this.setState({ fname : 'ram'});
    this.state.users.push({ firstName: this.state.fname });
    this.setState({ users: this.state.users });
    var promise = fetch(`https://itunes.apple.com/search?term=${this.state.fname}&limit=`);
    promise.then((response) => {
      response.json().then((data) => {
        // filter
        this.setState({
          users: data.results.filter(track => track.trackName && track.trackPrice &&
            track.trackId)
        });;
      })
    },
      function (error) {
        alert(error);
      })
    // this.setState({users :[ ...this.state.users,{firstName:this.state.fname}]});
  }

  render() {
    return (
      <div className="App">
        <input onChange={this.update = this.update.bind(this)} value={this.state.fname} />
        <input />
        <button onClick={this.display}>search</button>
        <button onClick={this.sort}>sort</button>
        <Counter count={this.state.users.length}></Counter>
        <Total totalSum={this.state.users.reduce(
          (accumulator, track) => track.trackPrice ? accumulator + track.trackPrice : accumulator, 0)}></Total>
        <ol>
          {this.state.users.map((user, index) => {
            return <li>{user.trackName}, {user.trackPrice}
              <img src={user.artworkUrl60}></img>
              <button onClick={() => {
                console.log(user.trackId);
                this.state.users.splice(index, 1);
                this.setState({users:this.state.users});
              }} >X</button>
            </li>
          })}
        </ol>
      </div>
    );
  }
}
export default Searchform;