import React, { Component } from 'react';
import { connect } from 'react-redux';

//  class Counter extends Component{
//      constructor(props){
//          super(props);
//      }
//     render(){
//         // this.props.count.push({});
//         // console.log('"çhild"');
//         return (
//             <div>records:</div>
//         )
//     }
// }

// var Counter = function (props) {
//     return (
//         <div>records:{props.count}</div>
//     )
// }
var Counter = (props) => {
    return (
        <div>records:{props.count}</div>
    )
}

function mapStateToProps(state, ownProps) {//state= redux state
    console.log('mapStateToProps', state);
    if (ownProps) {
        return ownProps.count = state.count;
    } else
        return {
            count: state.count
        };
}

export default connect(mapStateToProps)(Counter);