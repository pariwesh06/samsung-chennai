import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reducer from './reduxStore/reducer';
import { createStore } from 'redux';
import {Provider} from 'react-redux';
import {BrowserRouter as Router, Route, Link } from "react-router-dom";
import Orderform from './components/Orderform/Orderform';
import  Searchform  from "./components/searchform/searchform";
const initialState = {count:0};
const store = createStore(
    reducer,
    initialState//initial state
);
ReactDOM.render(<Provider store={store}>
    <Router>
    <div>
      <ul>
        <li>
          <Link to="/">Home</Link>
        </li>
        <li>
          <Link to="/order">About</Link>
        </li>
      </ul>

      <hr />

      <Route exact path="/" component={App} />
      <Route path="/order" component={Searchform} />
    </div>
  </Router>
</Provider>, document.getElementById('root'));

