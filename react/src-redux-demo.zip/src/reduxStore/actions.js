export  function save(data){
    console.log('in action', data);
    const actionPayload =  {
        type:'add',
        count:data
    }
    return actionPayload;
}