export default function reducers(state, action) {
    console.log(state, action);
    switch (action.type) {
        case 'add':
            return {
               count:action.count
            }
        default:
            return state;
    }
}