import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class App extends Component {
  constructor() {
    super();
    this.state = { fname: 'kishor', users: [] };
    this.sorted=true;
    this.display = this.display.bind(this);

  }
  update(event) {
    // console.log(event.target.value);
    this.setState({ fname: event.target.value });
  }

  display() {
    // console.log(this.state.fname);
    // this.setState({ fname : 'ram'});
    this.state.users.push({ firstName: this.state.fname });
    this.setState({ users: this.state.users });
    var promise = fetch(`https://itunes.apple.com/search?term=${this.state.fname}&limit=5`);
    promise.then((response) => {
      response.json().then((data) => {
        this.setState({ users: data.results });;
      })
    },
      function (error) {
        alert(error);
      })
    // this.setState({users :[ ...this.state.users,{firstName:this.state.fname}]});
  }

  render() {
    return (
      <div className="App">
        <input onChange={this.update = this.update.bind(this)} value={this.state.fname} />
        <button onClick={this.display}>search</button>
        <button onClick={this.sort}>sort</button>
        <ol>
          {this.state.users.map(function (user) {
            return <li>{user.trackName}, {user.trackPrice}</li>
          })}
        </ol>
      </div>
    );
  }
}

export default App;
